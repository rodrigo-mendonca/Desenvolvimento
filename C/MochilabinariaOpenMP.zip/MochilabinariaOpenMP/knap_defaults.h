#if !defined(KNAP_DEFAULTS_H)
#define KNAP_DEFAULTS_H

#define DEFAULT_N_BOOKS 5000
#define DEFAULT_BAG_CAP 1000
#define DEFAULT_max_random_weight 2000
#define DEFAULT_max_random_profit 50


#endif /* KNAP_DEFAULTS_H */
